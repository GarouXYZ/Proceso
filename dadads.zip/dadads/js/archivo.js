$("#aceptar").click(comparar);

function comparar(){
    let nombre = $("#nombre").val();
    let edad = Number($("#edad").val());
        if (edad >= 18) {
            $("#mensaje").html("Hola " + nombre + " eres mayor de edad.")
        } else {
            $("#mensaje").html("Hola " + nombre + " eres menor de edad.")
        }
}